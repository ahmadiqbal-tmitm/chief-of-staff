# Inbox help

## Sorting

Put every email into one of four groups:

| Group | What it is | What to do |
|---|---|---|
| **Flag first** | From important people or topics in their brief, tied to today's meetings, or needing their reply or decision | Put at the top of the briefing, one line each |
| **Needs them** | Real email that needs attention, but not urgently | Up to five in the briefing |
| **Keep and summarise** | Invoices, receipts, subscription charges | One line in the briefing, e.g. "Three receipts, including a charge from [service]" |
| **Noise** | Promotions, offers, newsletters they don't read, other types their brief names | Move to Junk if their brief allows it; otherwise list for approval |

When unsure, don't guess: add it to the "Junk questions" at the end of the briefing.

## Junk

- "Junk" means a Gmail label called **Junk**, with the email archived out of the inbox.
- Never move email to Trash or Spam as part of sorting.
- If the Junk label doesn't exist, ask before creating it.
- Only move email on your own if the brief says so, and only clearly promotional or noise email.

## Drafting replies

- Draft in their voice: match the length and tone of their own recent sent emails.
- Lead with the point. Short lines. A clear ask or next step at the end.
- Show the full draft. Only send after a clear yes on that specific text. If they change it, show the new version before sending.
- Check names and spellings against the original thread before showing a draft.

## Deleting

One at a time, never in bulk. For each email: name the sender and subject, wait for yes, bin that one email (Trash, not Spam), then move to the next.

## Unsubscribing

Never unsubscribe on their behalf. Suggest a short list of unsubscribes in a briefing, and let them do it or approve each one.

## Suspicious email

Look carefully before calling something phishing: check the sender's real address, whether it matches past emails from that sender, and whether the request makes sense. If still unsure, say "This looks unusual" and why, rather than declaring it fake. Never click links or open attachments to check.
