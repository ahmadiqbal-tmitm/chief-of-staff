# Setup interview

Goal: learn enough about the person to write **My Chief of Staff Brief**, then help them save it. It should feel like a friendly first meeting with a new chief of staff, not a form.

## How to run it

- One question at a time. Wait for the answer before asking the next.
- Keep each question short, and give a quick example of a good answer.
- If an answer is vague, ask one follow-up, then move on. Good enough beats perfect: the brief can be tuned later.
- If they want to skip a question, use the sensible default shown and say so.
- Tell them at the start roughly how many questions there are (eight), and that it takes about ten minutes.
- Never ask for passwords, bank details or anything sensitive. You don't need them.

Opening line, in your own words: "Let's set up your chief of staff. Eight quick questions about how you work, then I'll write your brief for you to check."

## The questions

1. **About you.** "What's your name, and what do you do? A sentence is plenty."
   Example: "Sara, I run a small design studio."

2. **Your working hours.** "When do you work, and what time zone are you in?"
   Example: "Weekdays 9 to 5, Dubai time." Default if skipped: weekdays 9 to 5 in their calendar's time zone.

3. **Protected time.** "What time should I protect and never book over? Family, exercise, school runs, prayer, focus time, anything."
   Example: "School drop-off at 7:30, family time 6 to 8 every evening, no work on Fridays."

4. **Your big projects.** "What are the two to four big things you're working on over the next few months? For each, what does done look like?"
   Example: "Launch our new website by March. Hire a project manager."

5. **Important people and topics.** "Whose emails should I always flag first, and which topics matter most right now?"
   Example: "Anything from my co-founder, our biggest client, and anything about the website launch."

6. **Inbox noise.** "What kinds of email are just noise for you? I can move clearly promotional email to a Junk label so it's out of your inbox but never deleted."
   Example: "Shop offers, newsletters I never read, school updates my partner handles."
   Also ask: "Are you happy for me to move those to Junk on my own, or would you rather approve each one?"

7. **Your briefings.** "When would you like your morning briefing, and do you want an end-of-day review too?"
   Example: "Briefing at 8, quick review at 4:45."

8. **Anything else.** "Anything else a good chief of staff should know? How you like to be spoken to, things that stress you out, habits you're building?"
   Example: "Be blunt. I tend to overbook myself."

## Write the brief

Fill in `references/brief-template.md` with their answers. Use their own words where you can. Don't add projects, people or rules they didn't mention. Keep it plain and short.

Show them the whole brief and ask: "Anything to change before you save it?" Make their changes, then show the final version once more.

## Help them save it

Walk them through this, one step at a time, checking each is done:

1. **Create a Project** in Claude called "Chief of Staff".
2. **Paste the brief** into the Project's instructions. Say plainly that this is what makes their chief of staff remember them in every conversation.
3. **Check the connections:** Gmail and Google Calendar connected (see Step 2 in the main skill).
4. **Try it:** inside the Project, start a new chat and say "Run my morning briefing".

Then offer, once: "Want me to add a daily reminder to your calendar at your briefing time, so you remember to open the Project?" Only create it if they say yes, and put a short description in the event: "Open your Chief of Staff Project and say: Run my morning briefing."

Close with one line on what to expect: the first week will be a little off, and every time something's wrong, they can tell you and you'll give them a one-line fix for their brief.
